安装说明：
1，安装openvpn-client.ovpn2.2.1-install.exe，一路回车
2，拷贝两个文件 ca.crt 和 jp01-route.ovpn、us01-route.ovpn 到目录 "C:\Program Files\OpenVPN\config"；
3，选择 “开始--程序--OpenVPN--OpenVPN GUI”， 之后右下角多了一个小图标，红色的，两个屏幕一个小球；
	如果操作系统是Vista/Win7, 需要选择 “开始--程序--OpenVPN--OpenVPN GUI”，鼠标右键--兼容性--选择“以管理员身份运行此程序”。
4，右键点击这个小图标，出现 "connect" 或者 “连接”, 点击；
5，之后弹出一个小窗口，属于你自己的用户名和密码，确定。很快就连上了，小图标变绿。

Quick installation:
1， Install openvpn-2.2.1-install.exe, all set by default;
2，Copy "ca.crt", "jp01-route.ovpn" and "us01-route.ovpn" into the folder "C:\Program Files\OpenVPN\config";
3， Click "Start" --> "Applications" --> "OpenVPN" --> "OpenVPN GUI", you will get an icon at right-bottom of your screen;
4，Right click the icon, select the access point you want, then click "connect";
5， Type in your username and password much straightforwardly, you will be quickly connected with the icon becoming green.